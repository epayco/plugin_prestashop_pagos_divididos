{*
* 2007-2021 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author    PrestaShop SA <contact@prestashop.com>
*  @copyright 2007-2021 PrestaShop SA
*  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*}

<!-- Nav tabs -->
<ul class="nav nav-tabs" role="tablist">
	<li class="active">
		<a href="#template_1" role="tab" data-toggle="tab">Registrar</a>
	</li>
	<li >
		<a href="#template_2" role="tab" data-toggle="tab">Listar/Eliminar</a>
	</li>
	<li>
		<a href="#template_3" role="tab" data-toggle="tab">Actualizar</a>
	</li>
</ul>

<!-- Tab panes -->
<div class="tab-content">
	<div class="tab-pane active" id="template_1">
		{include file='./template_1.tpl'}
	</div>
	<div class="tab-pane" id="template_2">
		{include file='./template_2.tpl'}
	</div>
	<div class="tab-pane" id="template_3">
		{include file='./template_3.tpl'}
	</div>
</div>
